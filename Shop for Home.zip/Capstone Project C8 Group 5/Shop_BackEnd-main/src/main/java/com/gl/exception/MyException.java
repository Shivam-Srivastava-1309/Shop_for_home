package com.gl.exception;


//import com.gl.enums.ResultEnum;


public class MyException extends RuntimeException {

    private Integer code;
    
    

    public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public MyException( String result) {
        super(result);

        //this.code = result.getCode();
    }

    public MyException(Integer code, String message) {
        super(message);
        this.code = code;
    }
}
