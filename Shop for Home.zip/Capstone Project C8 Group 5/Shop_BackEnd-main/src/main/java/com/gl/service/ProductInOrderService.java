package com.gl.service;

import com.gl.entity.ProductInOrder;
import com.gl.entity.User;


public interface ProductInOrderService {
    void update(String itemId, Integer quantity, User user);
    ProductInOrder findOne(String itemId, User user);
}
