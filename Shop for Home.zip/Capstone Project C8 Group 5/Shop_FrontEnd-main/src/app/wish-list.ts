export class WishList {
}
