export enum CategoryType {
    "flowervase", "wall paintings", "Decor paints","flora"
}
